document.addEventListener('DOMContentLoaded', () => {
    const isAuthenticated = true; // Simulated authentication check
    const correctAnswers = {
        q1: 'Paris', q2: 'Tokyo', q3: 'Ottawa', q4: 'Canberra',
        q5: 'Cairo', q6: 'New Delhi', q7: 'Rome', q8: 'Pretoria',
        q9: 'London', q10: 'Brasília'
    };
    const totalQuestions = Object.keys(correctAnswers).length;
    const quizForm = document.getElementById('quiz-form');
    const restartBtn = document.getElementById('restart-btn');
    const progressBar = document.getElementById('progress-bar');
    let score = 0;
    let answeredQuestions = 0; // Keeps track of the number of answered questions for the progress bar

    if (!isAuthenticated) {
        alert('You are not authenticated to take this quiz.');
        quizForm.style.display = 'none'; // Hides the quiz form if not authenticated
        return;
    }

    quizForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevents default form submission
        score = 0; // Resets score for each submission

        // Tallys the score based on correct answers
        Object.keys(correctAnswers).forEach(question => {
            const userAnswer = (document.querySelector(`input[name="${question}"]:checked`) || {}).value;
            if (userAnswer === correctAnswers[question]) {
                score += 10; // Adds points for correct answers
            }
        });

        // Displays the final score
        alert(`Your score is: ${score}/100`);
    });

    // Sets up immediate feedback and lock in answers
    Object.keys(correctAnswers).forEach(question => {
        const inputs = document.querySelectorAll(`input[name="${question}"]`);
        inputs.forEach(input => {
            input.addEventListener('change', () => {
                // Immediately provides feedback and update progress
                const selectedOption = input.parentNode;
                if (input.value === correctAnswers[question]) {
                    selectedOption.classList.add('correct');
                    selectedOption.classList.remove('incorrect');
                } else {
                    selectedOption.classList.add('incorrect');
                    selectedOption.classList.remove('correct');
                }

                // Disables other options to prevent changing the answer
                inputs.forEach(inp => {
                    if (inp !== input) {
                        inp.disabled = true; // Disables the input
                    }
                });

                // Updates the progress bar
                answeredQuestions++;
                const progressPercentage = (answeredQuestions / totalQuestions) * 100;
                progressBar.style.width = `${progressPercentage}%`;
            });
        });
    });

    restartBtn.addEventListener('click', () => {
        // Resets the form
        document.getElementById('quiz-form').reset();

        // Clears any added styles or feedback for correct/incorrect answers
        document.querySelectorAll('.question label').forEach(label => {
            label.classList.remove('correct', 'incorrect');
            label.querySelector('input').disabled = false; // Re-enables the input if it was disabled
        });

        // Resets the progress bar and answered questions counter
        answeredQuestions = 0;
        progressBar.style.width = '0%';
    });
});
